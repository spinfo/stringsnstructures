package modules.matrix;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.Collections;
import java.util.Comparator;
import java.util.Map;
import java.util.Set;
import java.util.Stack;

import models.NamedFieldMatrix;
import common.logicBits.LogOp;


public class MatrixDynamicMorphClustering {
	
	/*
	 * (there are three main data structures:
	 * 1. a dynamic (i.e. extensible) property matrix; the properties are
	 * vectors representing adjacency.
	 * The matrix must be extensible as new entries may be entered after
	 * comparison based on bitwise operations for bit(set)s not included
	 * in comparison.
	 * 2. a dynamic distance matrix which represents results of above
	 * vector comparison
	 * 3. an agglomerative (bottom up builded) neighbor hood tree
	 * )
	 * 
1. sortiere fallend nach Zahl Kontextelemente
2. Schleife: seligiere top down element a
3. Schleife bottom up:
	suche zwei Elemente b und c, deren Summe Kontextelemente >=
	Kontextelemente top-down

4: Evaluiere bitMatch:
	evaluiere results: (a AND b) OR(a AND c)  == a
	Evaluationskriterium: Ausgewogenheit, d.h. bestes b und c, dann wenn Differenz (Zahl gesetzte bits) |b| und |c|  m�glichst nahe 0


5. F�ge gesplittete Elemente in Liste ein
6. F�ge ein auch in fallend sortierte Liste
7. Iteriere Verfahren (auch) f�r neueingef�gte Elemente (das Vorgehen ist bin�r aufteilend).

	 * 
	 */

	// The value zero as a double
	private static final Double ZERO_D = new Double(0.0);
	
	private static Stack<MatrixDynamicMorphClusteringEntryBitValue> best,actual;
	
	private BitSet generateBitVector(NamedFieldMatrix namedFieldMatrix,int row) {
		double[] values;

		values = namedFieldMatrix.getRow(row);
		
		// create the BitSet from the matrix' values
		BitSet result = new BitSet(values.length);
		for (int i = 0; i < values.length; i++) {
			if (!ZERO_D.equals(values[i])) {
				result.set(i);
				}
			}//
		return result;
		}//generateBitVector
	
	// generates a list of context bits set in falling order
	ArrayList<MatrixDynamicMorphClusteringEntryBitValue> generateSorted(NamedFieldMatrix namedFieldMatrix)
		{
		ArrayList<MatrixDynamicMorphClusteringEntryBitValue> contextBitSetList=
				new ArrayList<MatrixDynamicMorphClusteringEntryBitValue>();
		System.out.println("MatrixDynamicMorphClustering generateSorted Entry");
		for (int i=0;i<namedFieldMatrix.getRowAmount();i++){
			
			
			BitSet bitSet = this.generateBitVector(namedFieldMatrix,i);
			//TODO save list of bits
			
			contextBitSetList.add(new MatrixDynamicMorphClusteringEntryBitValue(
					i,bitSet.cardinality(),bitSet));
		}
		
		// sort
		Collections.sort(contextBitSetList, 
				new Comparator <MatrixDynamicMorphClusteringEntryBitValue>(){
				 @Override
				    public int compare(MatrixDynamicMorphClusteringEntryBitValue a,
				    		MatrixDynamicMorphClusteringEntryBitValue b) {
					 		if (a.value < b.value)return 1;
					 		else if (a.value == b.value) return 0;
					 		else return-1;				        
				    }// compare
		});//sort
		
		// print for test
		System.out.println("MatrixDynamicMorphClustering generateSorted List");
		for (int i=0;i<contextBitSetList.size();i++){
			System.out.println(namedFieldMatrix.getRowName(contextBitSetList.get(i).rowIndex)+
					"  "+contextBitSetList.get(i).rowIndex+ "  "+
					contextBitSetList.get(i).value);
		}
		System.out.println("MatrixDynamicMorphClustering generateSorted Exit");
		return contextBitSetList;
	}
	
	// contextBitSetList contains entries which belong to differenung
	// morphological classes, e.g. regiere, regierst, regierbar, regierung
	// or porto, porta, porti, portiamo
	// these entries match with contexts of other entries which are clearly verbal,
	// adjectival or nominal
	// generateSpecificContextEntries proposes different forms of polyfunctional entries
	// 
	private void generateSpecificContextEntries
	(ArrayList<MatrixDynamicMorphClusteringEntryBitValue> contextBitSetList,
			NamedFieldMatrix namedFieldMatrix,PrintWriter writer){
		writer.println("MatrixDynamicMorphClustering generateSpecificContextEntries Entry");	
	
		// contextBitSetList is sorted after descending number of contexts
		// it is checked whether there are different elements with context contained
		// in selected element
		for (int i=0;i<contextBitSetList.size();i++){
			MatrixDynamicMorphClusteringEntryBitValue selectedElement=
					contextBitSetList.get(i);
					writer.println
					("MatrixDynamicMorphClustering generateSpecificContextEntries selectedElement "
					+ namedFieldMatrix.getRowName(selectedElement.rowIndex)+
					" cardinality: "+selectedElement.bitSet.cardinality());
					check(contextBitSetList,selectedElement,i,contextBitSetList.size()-1,0,namedFieldMatrix,writer);
					if (!this.actual.empty()){
						MatrixDynamicMorphClusteringEntryBitValue top= this.actual.peek();
						if (top != null) 
							writer.println("generateSpecificContextEntries stack best val:"+top.bitSet.cardinality());
						else writer.println("generateSpecificContextEntries stack empty");
						this.actual.clear();
					}
		}
		// enter in contextBitSetList
		writer.println("MatrixDynamicMorphClustering generateSpecificContextEntries Exit");
	}
	
	
	/*private void check1(ArrayList<MatrixDynamicMorphClusteringEntryBitValue> contextBitSetList,
			MatrixDynamicMorphClusteringEntryBitValue selectedElement,
			int i/ *value of outer calling loop s.above* /,int pos,int depth,
			NamedFieldMatrix namedFieldMatrix,PrintWriter writer){
		writer.println("MatrixDynamicMorphClustering check entry depth: "+depth+
				" startForLoop: "+pos);
		// terminate
		if (pos>=contextBitSetList.size()) return;
		
	}*/
	
	
	private void check(ArrayList<MatrixDynamicMorphClusteringEntryBitValue> contextBitSetList,
			MatrixDynamicMorphClusteringEntryBitValue selectedElement,
			int i/*value of outer calling loop s.above*/,int startForLoop,int depth,
			NamedFieldMatrix namedFieldMatrix,PrintWriter writer){
		writer.println("MatrixDynamicMorphClustering check entry depth: "+depth+
				" startForLoop: "+startForLoop);
		//	BitSet selectedElementBitSet=getBitSet(selectedElement);
		// select element (named localElement) out of contextBitSetList (in reversed order (from size() to j!))
		// which may be contained (bitwise) in selected element.
		for (int j=startForLoop;j>i;j--){
			MatrixDynamicMorphClusteringEntryBitValue localElement=
					contextBitSetList.get(j);	
			/*writer.println
			("MatrixDynamicMorphClustering check localElement "
			+ namedFieldMatrix.getRowName(localElement.rowIndex)+ " depth: "+depth + " j: "+j);
			*/
			switch(bitVectorCompare(selectedElement,localElement,j,writer))
			{
				case -1: 
				   // not contained,continue
				   break; 
				case 0: 
				   // contained, but not completely contained, recursion
					//int x=0;
				   //if (depth<10)
				   check(contextBitSetList,selectedElement,i,j-1,depth+1,namedFieldMatrix,writer);
				   break; 
				case 1: 
					// completely contained, check recursion depth
					// compare with result already found
				    return; 
				default:
				// nothing, 
					break
				  ;
			}
			
		}
		
	}
	
	
	// -1 not contained
	// 0  contained, but not completely contained, recursion
	// 1 completely contained, ok
	private int bitVectorCompare(MatrixDynamicMorphClusteringEntryBitValue selectedElement,
			MatrixDynamicMorphClusteringEntryBitValue localElement,int row,PrintWriter writer) {
		
		writer.println("bitVectorCompare Entry");
		// not contained
		BitSet resSelectedElementANDLocalElement=LogOp.AND(selectedElement.bitSet,localElement.bitSet);
		if (resSelectedElementANDLocalElement.isEmpty()) {
			writer.println("bitVectorCompare isEmpty -1 "); return -1;
		}
		else if (!isDisjunct(localElement.bitSet,writer)) {
			writer.println("bitVectorCompare not disjunct -1 ");return -1;
		}
		else {
			int resVal= isContained(selectedElement.bitSet,//localElement.bitSet,		
			resSelectedElementANDLocalElement,row,writer);
			writer.println("bitVectorCompare resVal: "+resVal);
			if (resVal == -1)
			{ return resVal;}
			else if (resVal ==0 ){
				
				return resVal;
			}
			else if (resVal==1)
			{
				checkNewBetter();
				return 1;
			}
			else if (resVal==2 ){
				// completely identical, nothing
				return resVal;
			}
			else { // error todo
				return -1;
				
			}
		}			
	}
	
	
	private boolean isDisjunct(BitSet localBitSet,PrintWriter writer){
		for (int i=0;i<actual.size();i++){
			
			BitSet res= LogOp.XOR(localBitSet,actual.get(i).bitSet);
			if(res.cardinality()<2){
				writer.println("isDisjunct false");
				return false;
			}
		}
		writer.println("isDisjunct true");
		return true;
	}//isDisjunct
	
	
	// is Contained checks whether new element contributes to context
	// -1 if element does not contribute
	// 0 if element contributes but not completely
	// 1 if elements contributes completely
	private int isContained(BitSet selectedElementBitSet,
			BitSet resSelectedElementANDLocalElementBitSet,int row,PrintWriter writer){
		
		if (this.actual.empty()){
			if (selectedElementBitSet.cardinality()==
					resSelectedElementANDLocalElementBitSet.cardinality())
			{
				writer.println("isContained completely identical");
				return 2;
			}
				
			writer.println("isContained first element continue");
			this.actual.push
			(new MatrixDynamicMorphClusteringEntryBitValue(row, 
				resSelectedElementANDLocalElementBitSet.cardinality(), 
				resSelectedElementANDLocalElementBitSet));
			return 0;
		}
		
		else {
			BitSet last= this.actual.peek().bitSet;
			BitSet res= LogOp.OR(resSelectedElementANDLocalElementBitSet,last);
			writer.println("last.cardinality: "+last.cardinality()+" res.cardinality: "+
			res.cardinality());
			// more contexts covered?
			if (res.cardinality() > last.cardinality()) 
				// all covered
				if (res.cardinality()==selectedElementBitSet.cardinality())
					{ writer.println("isContained all covered");return 1;}
				else {writer.println("isContained not all covered continue");
					this.actual.push
					(new MatrixDynamicMorphClusteringEntryBitValue(row, 
						resSelectedElementANDLocalElementBitSet.cardinality(), res));
					return 0;}
			else {writer.println("isContained element does not contribute"); return -1;
			}
		}
		
	}//isContained
	
	private void checkNewBetter(){
		if (best==null) best= actual;
		else {
			// better more elements than less
			if (actual.size()>best.size()) best=actual;
			else if (actual.size()==best.size()){
				if (harmony(actual)<harmony(best))best=actual;
			}
		}
	}
		
	private double harmony(Stack<MatrixDynamicMorphClusteringEntryBitValue>stack){
		int sum=0; double medium;double variation=0;
		for (int i=0;i<stack.size();i++){
			sum=sum+stack.get(i).value;
		}
		medium=sum/stack.size();
		for (int i=0;i<stack.size();i++){
			variation=variation + (Math.abs(stack.get(i).value-medium));
		}
		return variation;
	}
	
	private void extendNamedFieldMatrix(NamedFieldMatrix namedFieldMatrix, 
			Stack<MatrixDynamicMorphClusteringEntryBitValue>stack,
			MatrixDynamicMorphClusteringEntryBitValue selectedElement){
		
		// copy values from namedFieldmatrix from elment.i to new row(s)
		// number of new rows in namedFieldMatrix
		String rowName= namedFieldMatrix.getRowName(selectedElement.rowIndex);
		for (int i=0;i<stack.size();i++){
			//columns
			// generate new row to add to namedFieldmatrix
			for (int j=0;j<stack.get(i).bitSet.size();j++){
				// bit is set, get value
				if (stack.get(i).bitSet.get(j)){
					double value= namedFieldMatrix.getValue(selectedElement.rowIndex,j);
					//????l�schen row ???
					String columnName=
					namedFieldMatrix.getColumnName(j);
					namedFieldMatrix.addValue(rowName+"-"+String.valueOf(i), columnName, value);
				}
			}
			
		}		
		
	}
	
	
	// TO DO stacks to be constructed (actual, best)
	// TO DO define central method restruct from which all is called here internally
	// TO DO documentation
	// TO check
	// 		after: distance matrix
	// 		clustering
	
	public NamedFieldMatrix restruct(NamedFieldMatrix namedFieldMatrix,
			PrintWriter writer){
		this.actual=new Stack<MatrixDynamicMorphClusteringEntryBitValue>();
		this.best=new Stack<MatrixDynamicMorphClusteringEntryBitValue>();
		writer.println("MatrixDynamicMorphClustering restruct Entry");
		// generates a list of context bits set in falling order
		ArrayList<MatrixDynamicMorphClusteringEntryBitValue> contextBitSetList=
		this.generateSorted(namedFieldMatrix);
		
		
		this.generateSpecificContextEntries(contextBitSetList,namedFieldMatrix,writer);
		
		// extendNamedFieldMatrix
		writer.println("MatrixDynamicMorphClustering restruct Exit");
		
		return null;
	}
	
}
